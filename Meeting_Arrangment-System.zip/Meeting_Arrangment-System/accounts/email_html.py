import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os

os.chdir(r'C:\Users\91934\Desktop\Meeting_Arrangment_Portal\Meeting_Arrangment-System\accounts\templates')
raport_file = open('visitor_mail_template.html')
alert_msg = MIMEText(raport_file.read(),"html", "utf-8")

raport_file = open('host_mail_template.html')
alert_msg = MIMEText(raport_file.read(),"html", "utf-8")

# me == my email address
# you == recipient's email address
me = "nikithagaddam1109@gmail.com"
you = "nikithagaddam1109@gmail.com"
subject = 'Test Subject v5'

# Create message container - the correct MIME type is multipart/alternative.
msg = MIMEMultipart('alternative')
msg['Subject'] = subject
msg['From'] = me
msg['To'] = you

# Create the body of the message (a plain-text and an HTML version).
text = "Hi!\nHow are you?"
html = raport_file.read()

# Record the MIME types of both parts - text/plain and text/html.
part1 = MIMEText(text, 'plain')
part2 = MIMEText(html, 'html')

# Attach parts into message container.
# According to RFC 2046, the last part of a multipart message, in this case
# the HTML message, is best and preferred.
msg.attach(part1)
msg.attach(part2)

# Send the message via local SMTP server.
server = smtplib.SMTP('smtp.gmail.com:587')
server.starttls()
server.login('nikithagaddam1109@gmail.com', 'frdvrbicrhtkusmd')

server.sendmail(me,you,alert_msg.as_string())
server.quit()

print('mail sent succcesfully!!')